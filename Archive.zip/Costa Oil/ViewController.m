//
//  ViewController.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 16/05/21.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:7 target:self selector:@selector(timerCalled) userInfo:nil repeats:NO];
        
}


-(void)timerCalled {

    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"LoginScreen"];
    [self presentViewController:vc animated:NO completion:nil];
    
}

@end
