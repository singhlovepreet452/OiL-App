//
//  LoginScreen.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 16/05/21.
//

#import "LoginScreen.h"
#import "MBProgressHUD.h"

@interface LoginScreen ()

@end

@implementation LoginScreen


- (void)viewDidLoad {
    
    [super viewDidLoad];
    
}


- (IBAction)loginBtn:(id)sender {
    
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(timerCalled) userInfo:nil repeats:NO];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];

        
}


-(void)timerCalled {
    
    
    [MBProgressHUD hideHUDForView:self.view animated:NO];


    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"SignInscreen"];
    [self presentViewController:vc animated:NO completion:nil];
    
}
@end
