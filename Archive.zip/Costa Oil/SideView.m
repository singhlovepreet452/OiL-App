//
//  SideView.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 17/05/21.
//

#import "SideView.h"

@interface SideView ()

@end

@implementation SideView


- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    
    
}


- (IBAction)availableOilList:(id)sender {
    
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"AvailableOilList"];
    [self presentViewController:vc animated:NO completion:nil];
    
    
}

- (IBAction)profile:(id)sender {
    
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"Profile"];
    [self presentViewController:vc animated:NO completion:nil];
    
    
}


- (IBAction)invoice:(id)sender {
    
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"Invoice"];
    [self presentViewController:vc animated:NO completion:nil];
    
    
}



- (IBAction)logout:(id)sender {
    
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Alert"
                                 message:@"Are you sure want to logout"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    //Add Buttons
    
    UIAlertAction* yesButton = [UIAlertAction
                                actionWithTitle:@"Logout"
                                style:UIAlertActionStyleDestructive
                                handler:^(UIAlertAction * action) {
        //Handle your yes please button action here
        
        NSString * storyboardName = @"Main";
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"LoginScreen"];
        [self presentViewController:vc animated:NO completion:nil];
        
    }];
    
    UIAlertAction* noButton = [UIAlertAction
                               actionWithTitle:@"No"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction * action) {
        
        // Handle no, thanks button
        
    }];
    
    //Add your buttons to alert controller
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    
}

@end
