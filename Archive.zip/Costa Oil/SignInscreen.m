//
//  SignInscreen.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 16/05/21.

#import "SignInscreen.h"
#import "MBProgressHUD.h"

@interface SignInscreen ()

@property (weak, nonatomic) IBOutlet UIView *view1;

@property (weak, nonatomic) IBOutlet UIView *view2;

@property (weak, nonatomic) IBOutlet UIView *view3;

@property (weak, nonatomic) IBOutlet UITextField *employeIDTXT;

@property (weak, nonatomic) IBOutlet UITextField *pwTxt;

@end

@implementation SignInscreen

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    _view1.layer.cornerRadius = 15;
    _view1.layer.masksToBounds = true;
    
    _view2.layer.borderColor = [UIColor grayColor].CGColor;
    _view2.layer.borderWidth = 1;
    _view2.layer.cornerRadius = 5;
    _view2.layer.masksToBounds = true;
    
    _view3.layer.borderColor = [UIColor grayColor].CGColor;
    _view3.layer.borderWidth = 1;
    _view3.layer.cornerRadius = 5;
    _view3.layer.masksToBounds = true;
    
    _employeIDTXT.delegate=self;
    _pwTxt.delegate=self;
    
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [self.view endEditing:YES];

    return YES;
    
}



- (IBAction)login:(id)sender {
    
    if ([_employeIDTXT.text isEqualToString:@"12345678"]) {
        
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        NSString * storyboardName = @"Main";
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"HomeScreen"];
        [self presentViewController:vc animated:NO completion:nil];
        
    }
    
    else{
        
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Alert"
                                     message:@"Please Enter Correct Employe ID..!"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        //Add Buttons
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"OK"
                                    style:UIAlertActionStyleDestructive
                                    handler:^(UIAlertAction * action) {
            
            
            //Handle your yes please button action here
            
//            NSString * storyboardName = @"Main";
//            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
//            UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"LoginScreen"];
//            [self presentViewController:vc animated:NO completion:nil];
            
        }];
        
//        UIAlertAction* noButton = [UIAlertAction
//                                   actionWithTitle:@"No"
//                                   style:UIAlertActionStyleDefault
//                                   handler:^(UIAlertAction * action) {
//
//            // Handle no, thanks button
//
//        }];
        
        //Add your buttons to alert controller
        
           [alert addAction:yesButton];
       //  [alert addAction:noButton];
        
        [self presentViewController:alert animated:YES completion:nil];
        
        
    }
    
    
    
    
   
    
    
}


- (IBAction)forgot:(id)sender {
    
    
}


- (IBAction)back:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}


@end
